var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__b89db0fc._.js")
R.c("server/chunks/[root-of-the-server]__f8d6cca1._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_9118e90f.js")
R.m(77067)
module.exports=R.m(77067).exports
