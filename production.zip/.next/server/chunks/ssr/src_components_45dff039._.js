module.exports=[96002,a=>{"use strict";var b=a.i(75716);a.i(64628);var c=a.i(45309),d=a.i(19044),e=a.i(14072);let f=b.default.div.withConfig({displayName:"MenuItem",componentId:"sc-f092b171-0"})`
  display: flex;
  cursor: pointer;
  align-items: center;
  padding: 0.5rem 1rem;
  word-break: break-all;
  color: ${(0,e.themeGet)("colors.text.secondary")};

  &:hover {
    color: ${(0,e.themeGet)("colors.primary.main")};
    background-color: ${(0,e.themeGet)("colors.gray.100")};
  }
  ${c.color}
  ${d.space}
`;a.s(["default",0,f])},22393,50089,85347,a=>{"use strict";var b=a.i(87924),c=a.i(38246),d=a.i(72131),e=a.i(71335),f=a.i(80719),g=a.i(66500),h=a.i(32371),i=a.i(94661),j=a.i(71987),k=a.i(20511),l=a.i(26735);a.i(27718);var m=a.i(4839),n=a.i(4371);a.i(18128);var o=a.i(79702),p=a.i(45112),q=a.i(75716);let r=q.default.div.withConfig({displayName:"styles__StyledMiniCart",componentId:"sc-1e1f8c7d-0"})`
  display: flex;
  height: 100vh;
  flex-direction: column;

  .cart-list {
    flex: 1 1 0;
    overflow: auto;
  }

  .cart-item {
    display: flex;
    padding: 1rem;
    align-items: center;

    .add-cart {
      text-align: center;
    }

    .product-image {
      width: 64px;
      height: 64px;
      margin-left: 1rem;
      border-radius: 5px;
      margin-right: 1rem;
    }

    .product-details {
      flex: 1 1 0;
      min-width: 0px;

      .title {
        margin: 0px;
        line-height: 1;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }

    .clear-icon {
      cursor: pointer;
      color: ${(0,p.getTheme)("colors.gray.600")};
    }
  }

  .actions {
    margin: 1rem 1rem 0.75rem;
  }
`;function s({toggleSidenav:a=()=>{}}){let{state:e,dispatch:f}=(0,o.useAppContext)(),g=(a,b)=>()=>{f({type:"CHANGE_CART_AMOUNT",payload:{...b,qty:a}})};return(0,b.jsxs)(r,{children:[(0,b.jsxs)("div",{className:"cart-list",children:[(0,b.jsxs)(i.default,{alignItems:"center",m:"0px 20px",height:"74px",children:[(0,b.jsx)(h.default,{size:"1.75rem",children:"bag"}),(0,b.jsxs)(n.default,{fontWeight:600,fontSize:"16px",ml:"0.5rem",children:[e.cart.reduce((a,b)=>a+b.qty,0)," items"]})]}),(0,b.jsx)(l.default,{}),!e.cart.length&&(0,b.jsxs)(i.default,{alignItems:"center",flexDirection:"column",justifyContent:"center",height:"calc(100% - 80px)",children:[(0,b.jsx)(j.default,{src:"/assets/images/logos/shopping-bag.svg",width:90,height:90,alt:"bonik"}),(0,b.jsx)(n.Paragraph,{mt:"1rem",color:"text.muted",textAlign:"center",maxWidth:"200px",children:"Your shopping bag is empty. Start shopping"})]}),e.cart.map(a=>(0,b.jsxs)(d.Fragment,{children:[(0,b.jsxs)("div",{className:"cart-item",children:[(0,b.jsx)(c.default,{href:`/product/${a.slug}`,children:(0,b.jsx)(k.default,{size:76,mr:"1rem",alt:a.name,src:a.imgUrl||"/assets/images/products/iphone-x.png"})}),(0,b.jsxs)("div",{className:"product-details",children:[(0,b.jsx)(c.default,{href:`/product/${a.id}`,children:(0,b.jsx)(n.H5,{className:"title",fontSize:"14px",children:a.name})}),(0,b.jsxs)(n.Tiny,{color:"text.muted",children:[(0,p.currency)(a.price,0)," x ",a.qty]}),(0,b.jsx)(n.default,{fontWeight:600,fontSize:"14px",color:"primary.main",mt:"4px",children:(0,p.currency)(a.qty*a.price)}),(0,b.jsxs)(i.default,{alignItems:"center",mt:"0.5rem",children:[(0,b.jsx)(m.Button,{size:"none",padding:"5px",color:"primary",variant:"outlined",borderRadius:"300px",borderColor:"primary.light",onClick:g(a.qty-1,a),children:(0,b.jsx)(h.default,{variant:"small",children:"minus"})}),(0,b.jsx)(n.default,{fontWeight:600,fontSize:"15px",mx:"1rem",children:a.qty}),(0,b.jsx)(m.Button,{size:"none",padding:"5px",color:"primary",variant:"outlined",borderRadius:"300px",borderColor:"primary.light",onClick:g(a.qty+1,a),children:(0,b.jsx)(h.default,{variant:"small",children:"plus"})})]})]}),(0,b.jsx)(h.default,{size:"1rem",ml:"1.25rem",className:"clear-icon",onClick:g(0,a),children:"close"})]}),(0,b.jsx)(l.default,{})]},a.id))]}),!!e.cart.length&&(0,b.jsxs)("div",{className:"actions",children:[(0,b.jsx)(c.default,{href:"/checkout",children:(0,b.jsx)(m.Button,{fullwidth:!0,color:"primary",variant:"contained",onClick:a,children:(0,b.jsxs)(n.default,{fontWeight:600,children:["Checkout Now (",(0,p.currency)(e.cart.reduce((a,b)=>a+b.price*b.qty,0)||0),")"]})})}),(0,b.jsx)(c.default,{href:"/cart",children:(0,b.jsx)(m.Button,{fullwidth:!0,color:"primary",variant:"outlined",mt:"1rem",onClick:a,children:(0,b.jsx)(n.default,{fontWeight:600,children:"View Cart"})})})]})]})}var t=a.i(4234),u=a.i(46156),v=a.i(27424),w=a.i(90696),x=a.i(63336),y=a.i(96002),z=a.i(20299);let A=q.default.div.withConfig({displayName:"styled__StyledSearchBox",componentId:"sc-81096f14-0"})`
  position: relative;
  display: flex;
  align-items: center;

  .search-icon {
    position: absolute;
    color: ${(0,p.getTheme)("colors.text.hint")};
    left: 1rem;
    z-index: 1;
  }

  .search-field {
    flex: 1 1 0;
    padding-left: 3rem;
    padding-right: 11.5rem;
    height: 44px;
    border-radius: 300px;
  }
  .search-button {
    position: absolute;
    height: 100%;
    right: 0px;
    border-radius: 0 300px 300px 0;
    padding-left: 55px;
    padding-right: 55px;
  }
  .category-dropdown {
    position: absolute;
    right: 0px;
    color: ${(0,p.getTheme)("colors.text.hint")};
  }
  .dropdown-handler {
    height: 40px;
    cursor: pointer;
    min-width: 90px;
    padding-left: 1.25rem;
    padding-right: 1rem;
    border-left: 1px solid ${(0,p.getTheme)("colors.text.disabled")};
    span {
      margin-right: 0.75rem;
    }
  }
  .menu-button {
    display: none;
  }
  @media only screen and (max-width: 900px) {
    .category-dropdown {
      display: none;
    }
    .search-icon {
      left: 1rem;
    }
    .search-field {
      height: 40px;
      border-radius: 300px;
      padding-left: 2.75rem;
      padding-right: 3.5rem;
    }
    .search-button {
      padding-left: 1.25rem;
      padding-right: 1.25rem;
    }
    .menu-button {
      display: unset;
    }
  }
`;function B(){let[a,e]=(0,d.useState)([]),g=(0,w.default)(async a=>{let b=a.target?.value;if(b)try{let a=await fetch(`https://admin.unicodeconverter.info/products/searchsuggest?search=${b}`),c=await a.json();if(c.products&&Array.isArray(c.products)){let a=c.products.map(a=>({id:a.id,product_name:a.pro_title||a.title||"Unknown Product",slug:a.pro_slug||a.slug||"",image:a.images&&a.images.length>0?`https://admin.unicodeconverter.info/storage/app/public/products/${a.images[0].img_name}`:"/assets/images/products/macbook.png"}));e(a)}else e([])}catch(a){console.error("Error fetching search suggestions:",a),e([])}else e([])},200),i=(0,d.useCallback)(a=>{a.persist(),g(a)},[]),j=()=>e([]);return(0,d.useEffect)(()=>(window.addEventListener("click",j),()=>window.removeEventListener("click",j)),[]),(0,b.jsxs)(f.default,{position:"relative",flex:"1 1 0",maxWidth:"670px",mx:"auto",children:[(0,b.jsxs)(A,{children:[(0,b.jsx)(h.default,{className:"search-icon",size:"18px",children:"search"}),(0,b.jsx)(z.default,{fullwidth:!0,onChange:i,className:"search-field",placeholder:"Search and hit enter..."})]}),!!a.length&&(0,b.jsx)(x.default,{position:"absolute",top:"100%",py:"0.5rem",width:"100%",boxShadow:"large",zIndex:99,style:{maxHeight:"400px",overflowY:"auto"},children:a.map(a=>(0,b.jsx)(c.default,{href:`/product/${a.slug}`,children:(0,b.jsxs)(y.default,{children:[(0,b.jsx)("img",{src:a.image,alt:a.product_name,style:{width:40,height:40,objectFit:"contain",marginRight:10}}),(0,b.jsx)(n.Span,{fontSize:"14px",children:a.product_name})]},a.id)},a.id))})]})}var C=a.i(71336);let D=q.default.header.withConfig({displayName:"styles__StyledHeader",componentId:"sc-13eb890c-0"})`
  z-index: 999;
  position: sticky;
  top: 0;
  height: ${C.layoutConstant.headerHeight};
  background: ${(0,p.getTheme)("colors.body.paper")};

  .logo {
    img {
      display: block;
    }
  }

  .icon-holder {
    span {
      font-size: 12px;
      line-height: 1;
      margin-bottom: 4px;
    }
    h4 {
      margin: 0px;
      font-size: 14px;
      line-height: 1;
      font-weight: 600;
    }
    div {
      margin-left: 6px;
    }
  }

  .user {
    cursor: pointer;
  }

  @media only screen and (max-width: 900px) {
    height: ${C.layoutConstant.mobileHeaderHeight};

    .logo,
    .icon-holder,
    .category-holder {
      display: none;
    }
    .header-right {
      display: none !important;
    }
  }
`;var E=a.i(28268);function F({handle:a,children:c}){let[e,f]=(0,d.useState)(!1),g=()=>f(!e);return(0,b.jsxs)(d.Fragment,{children:[(0,d.cloneElement)(a,{onClick:g}),(0,b.jsx)(E.default,{open:e,onClose:g,children:c})]})}function G({isFixed:a,className:j}){let{state:k}=(0,o.useAppContext)(),[l,m]=(0,d.useState)(!1),p=()=>m(!l),q=(0,b.jsxs)(f.default,{ml:"20px",position:"relative",children:[(0,b.jsx)(u.IconButton,{bg:"gray.200",p:"12px",size:"small",children:(0,b.jsx)(h.default,{size:"20px",children:"bag"})}),!!k.cart.length&&(0,b.jsx)(i.default,{top:-5,right:-5,height:20,minWidth:20,bg:"primary.main",borderRadius:"50%",alignItems:"center",position:"absolute",justifyContent:"center",children:(0,b.jsx)(n.Tiny,{color:"white",fontWeight:"600",lineHeight:1,children:k.cart.reduce((a,b)=>a+b.qty,0)})})]}),r=(0,b.jsx)(u.IconButton,{ml:"1rem",bg:"gray.200",p:"8px",children:(0,b.jsx)(h.default,{size:"28px",children:"user"})});return(0,b.jsx)(D,{className:j,children:(0,b.jsxs)(t.default,{display:"flex",alignItems:"center",justifyContent:"space-between",height:"100%",children:[(0,b.jsx)(i.default,{className:"logo",alignItems:"center",mr:"1rem",children:(0,b.jsx)(c.default,{href:"/",children:(0,b.jsxs)(i.default,{alignItems:"center",children:[(0,b.jsx)(g.default,{src:"/assets/images/rambd_logo.webp",alt:"RamBD Logo",height:44}),(0,b.jsxs)(n.H2,{fontWeight:"700",ml:"10px",color:"primary.main",fontSize:"40px",children:["Ram",(0,b.jsx)("span",{style:{color:"#27ae60"},children:"BD"})]})]})})}),(0,b.jsx)(i.default,{justifyContent:"center",flex:"1 1 0",children:(0,b.jsx)(B,{})}),(0,b.jsxs)(i.default,{className:"header-right",alignItems:"center",children:[(0,b.jsx)(F,{handle:r,children:(0,b.jsx)("div",{children:(0,b.jsx)(e.default,{})})}),(0,b.jsx)(v.default,{open:l,width:380,position:"right",handle:q,toggleSidenav:p,children:(0,b.jsx)(s,{toggleSidenav:p})})]})]})})}a.s([],22393),a.s(["Header",()=>G],50089);var H=a.i(32111),I=a.i(70135),J=a.i(77853);let K=q.default.div.withConfig({displayName:"mobile-navigation__Wrapper",componentId:"sc-6bc53034-0"})`
  left: 0;
  right: 0;
  bottom: 0;
  display: none;
  position: fixed;
  align-items: center;
  justify-content: space-around;
  height: ${C.layoutConstant.mobileNavHeight};
  background: ${(0,p.getTheme)("colors.body.paper")};
  box-shadow: 0px 1px 4px 3px rgba(0, 0, 0, 0.1);
  z-index: 999;

  .link {
    flex: 1 1 0;
    display: flex;
    font-size: 13px;
    align-items: center;
    flex-direction: column;
    justify-content: center;

    .icon {
      display: flex;
      margin-bottom: 4px;
      align-items: center;
      justify-content: center;
    }
  }

  @media only screen and (max-width: 900px) {
    display: flex;
    width: 100vw;
  }
`;function L(){let a=(0,J.default)(),{state:c}=(0,o.useAppContext)();return a<=900?(0,b.jsx)(K,{children:M.map(a=>(0,b.jsxs)(I.default,{className:"link",href:a.href,children:[(0,b.jsx)(h.default,{className:"icon",variant:"small",children:a.icon}),a.title,"Cart"===a.title&&!!c.cart.length&&(0,b.jsx)(H.Chip,{top:"4px",px:"0.25rem",fontWeight:"600",bg:"primary.main",position:"absolute",color:"primary.text",left:"calc(50% + 8px)",children:c.cart.reduce((a,b)=>a+b.qty,0)})]},a.title))}):null}let M=[{title:"Home",icon:"home",href:"/"},{title:"Category",icon:"category",href:"/mobile-category-nav"},{title:"Cart",icon:"bag",href:"/cart"},{title:"Account",icon:"user-2",href:"/profile"}];a.s(["default",()=>L],85347)}];

//# sourceMappingURL=src_components_45dff039._.js.map