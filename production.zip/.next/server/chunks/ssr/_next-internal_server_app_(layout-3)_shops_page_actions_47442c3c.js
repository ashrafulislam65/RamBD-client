module.exports=[39460,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28layout-3%29_shops_page_actions_47442c3c.js.map