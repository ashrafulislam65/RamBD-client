module.exports=[73023,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28layout-3%29_shops_%5Bslug%5D_page_actions_c9de1d9d.js.map