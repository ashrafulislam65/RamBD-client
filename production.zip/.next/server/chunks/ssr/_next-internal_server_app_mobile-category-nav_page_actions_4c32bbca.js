module.exports=[28069,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mobile-category-nav_page_actions_4c32bbca.js.map