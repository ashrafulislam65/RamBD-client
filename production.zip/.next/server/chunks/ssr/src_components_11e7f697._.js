module.exports=[32786,93961,84894,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(75716);a.i(64628);var e=a.i(25851),f=a.i(1469),g=a.i(14072),h=a.i(45112);let i=d.default.div.withConfig({shouldForwardProp:a=>(0,h.isValidProp)(a),displayName:"Menu__StyledMenu",componentId:"sc-d4da9df6-0"})((0,f.default)({position:"relative",".menu-item-holder":{zIndex:100,minWidth:"200px",borderRadius:"6px",paddingTop:"0.5rem",position:"absolute",paddingBottom:"0.5rem",top:"calc(100% + 0.5rem)",backgroundColor:(0,g.themeGet)("body.paper","#ffffff"),boxShadow:(0,g.themeGet)("shadows.3","0 6px 12px rgba(0, 0, 0, 0.16)")}}),(0,e.variant)({prop:"direction",variants:{left:{".menu-item-holder":{left:0,right:"auto"}},right:{".menu-item-holder":{left:"auto",right:0}}}}));function j({handler:a,children:d,direction:e="left",...f}){let[g,h]=(0,c.useState)(!1),j=(0,c.useRef)(g);j.current=g;let k=()=>{j.current&&h(!1)};return(0,c.useEffect)(()=>(window.addEventListener("click",k),()=>window.removeEventListener("click",k)),[]),(0,b.jsxs)(i,{direction:e,...f,children:[(0,c.cloneElement)(a,{onClick:a=>{a.stopPropagation(),h(!g)}}),g&&(0,b.jsx)("div",{className:"menu-item-holder",children:d})]})}var k=a.i(66500),l=a.i(32371),m=a.i(94661),n=a.i(70135),o=a.i(96002),p=a.i(4234),q=a.i(4371);let r=d.default.div.withConfig({displayName:"styles__StyledTopbar",componentId:"sc-a1676d95-0"})`
  background: ${(0,h.getTheme)("colors.secondary.main")};
  color: white;
  height: 40px;
  font-size: 12px;

  .topbar-left {
    .logo {
      display: none;
      img {
        display: block;
        height: 36px;
      }
    }
    span {
      margin-left: 10px;
    }
    @media only screen and (max-width: 900px) {
      .logo {
        display: block;
      }
      *:not(.logo) {
        display: none;
      }
    }
  }

  .topbar-right {
    .link {
      padding-right: 30px;
      color: white;
    }
    .dropdown-handler {
      cursor: pointer;
      img {
        height: 14px;
        border-radius: 4px;
      }
      span {
        margin-right: 0.25rem;
        margin-left: 0.5rem;
      }
    }
    @media only screen and (max-width: 900px) {
      .link {
        display: none;
      }
    }
  }
`;function s(){let[a,d]=(0,c.useState)(u[0]),[e,f]=(0,c.useState)(t[0]);return(0,c.useEffect)(()=>{},[]),(0,b.jsx)(r,{children:(0,b.jsxs)(p.default,{display:"flex",justifyContent:"space-between",alignItems:"center",height:"100%",children:[(0,b.jsxs)(m.default,{className:"topbar-left",children:[(0,b.jsxs)(m.default,{alignItems:"center",children:[(0,b.jsx)(l.default,{size:"14px",children:"phone-call"}),(0,b.jsx)("span",{children:"+880 1847-117888"})]}),(0,b.jsxs)(m.default,{alignItems:"center",ml:"20px",children:[(0,b.jsx)(l.default,{size:"14px",children:"mail"}),(0,b.jsx)("span",{children:"info@rambd.com"})]})]}),(0,b.jsxs)(m.default,{className:"topbar-right",alignItems:"center",children:[(0,b.jsx)(n.default,{className:"link",href:"/",children:'Theme FAQ"s'}),(0,b.jsx)(n.default,{className:"link",href:"/",children:"Need Help?"}),(0,b.jsx)(j,{direction:"right",handler:(0,b.jsxs)(m.default,{className:"dropdown-handler",alignItems:"center",height:"40px",children:[(0,b.jsx)(k.default,{src:e.imgUrl,alt:e.title}),(0,b.jsx)(q.Small,{fontWeight:"600",children:e.title}),(0,b.jsx)(l.default,{size:"1rem",children:"chevron-down"})]}),children:t.map(a=>(0,b.jsxs)(o.default,{onClick:()=>f(a),children:[(0,b.jsx)(k.default,{src:a.imgUrl,borderRadius:"2px",mr:"0.5rem",alt:a.title}),(0,b.jsx)(q.Small,{fontWeight:"600",children:a.title})]},a.title))})]})]})})}let t=[{title:"EN",imgUrl:"/assets/images/flags/usa.png"},{title:"BN",imgUrl:"/assets/images/flags/bd.png"},{title:"HN",imgUrl:"/assets/images/flags/in.png"}],u=[{title:"USD",imgUrl:"/assets/images/flags/usa.png"},{title:"EUR",imgUrl:"/assets/images/flags/uk.png"},{title:"BDT",imgUrl:"/assets/images/flags/bd.png"},{title:"INR",imgUrl:"/assets/images/flags/in.png"}];a.s(["default",()=>s],32786);var v=a.i(38246),w=a.i(80719),x=a.i(29620);let y=(0,d.default)(v.default).withConfig({displayName:"styles__StyledLink",componentId:"sc-2a9a6b20-0"})`
  position: relative;
  display: block;
  padding: 0.3rem 0rem;
  color: ${(0,h.getTheme)("colors.gray.500")};
  cursor: pointer;
  border-radius: 4px;
  &:hover {
    color: ${(0,h.getTheme)("colors.gray.100")};
  }
`,z=["Contact Us","Order procedure","Delivery Rules","Return Policy"],A=["All Products","Delivery Rules","Return Policy","Terms & Conditions","Privacy Policy"],B=[{iconName:"facebook",url:"https://www.facebook.com/rambd"},{iconName:"whatsapp",url:"https://wa.me/8801847117888"},{iconName:"youtube",url:"https://www.youtube.com/@rambd"},{iconName:"instagram",url:"https://www.instagram.com/rambd"}];function C(){return(0,b.jsx)(w.default,{as:"footer",bg:"#0F3460",children:(0,b.jsxs)(p.default,{p:"1rem",color:"white",children:[(0,b.jsx)(w.default,{py:"5rem",overflow:"hidden",children:(0,b.jsxs)(x.default,{container:!0,spacing:6,children:[(0,b.jsxs)(x.default,{item:!0,lg:4,md:6,sm:6,xs:12,children:[(0,b.jsx)(v.default,{href:"/",children:(0,b.jsx)(k.default,{alt:"RamBD Logo",mb:"1.25rem",src:"/assets/images/rambd_logo.webp",height:40})}),(0,b.jsx)(q.default,{py:"0.3rem",mb:"1rem",color:"gray.500",children:"Phone: +880 1847-117888"})]}),(0,b.jsxs)(x.default,{item:!0,lg:2,md:6,sm:6,xs:12,children:[(0,b.jsx)(q.default,{mb:"1.25rem",lineHeight:"1",fontSize:20,fontWeight:"600",children:"USEFUL LINK"}),(0,b.jsx)("div",{children:z.map((a,c)=>(0,b.jsx)(y,{href:"/",children:a},c))})]}),(0,b.jsxs)(x.default,{item:!0,lg:3,md:6,sm:6,xs:12,children:[(0,b.jsx)(q.default,{mb:"1.25rem",lineHeight:"1",fontSize:20,fontWeight:"600",children:"LINK"}),(0,b.jsx)("div",{children:A.map((a,c)=>(0,b.jsx)(y,{href:"/",children:a},c))})]}),(0,b.jsxs)(x.default,{item:!0,lg:3,md:6,sm:6,xs:12,children:[(0,b.jsx)(q.default,{mb:"1.25rem",lineHeight:"1",fontSize:20,fontWeight:"600",children:"FOLLOW US"}),(0,b.jsx)(m.default,{className:"flex",mx:"-5px",children:B.map(a=>(0,b.jsx)("a",{href:a.url,target:"_blank",rel:"noreferrer noopenner",children:(0,b.jsx)(w.default,{m:"5px",p:"10px",size:"small",borderRadius:"50%",bg:"rgba(0,0,0,0.2)",children:(0,b.jsx)(l.default,{size:"12px",defaultcolor:"auto",children:a.iconName})})},a.iconName))})]})]})}),(0,b.jsx)(w.default,{py:"1rem",borderTop:"1px solid rgba(255,255,255,0.1)",children:(0,b.jsx)(q.default,{color:"gray.500",textAlign:"center",fontSize:14,children:"Copyright © 2026 RamBD. All rights reserved | Website Designed by: IGL Web Ltd"})})]})})}var D=a.i(71336);(0,d.default)(v.default).withConfig({displayName:"styles__StyledLink",componentId:"sc-a8997a5a-0"})`
  z-index: 999;
  display: block;
  cursor: pointer;
  position: relative;
  border-radius: 4px;
  padding: 0.35rem 0rem;
  color: ${(0,h.getTheme)("colors.gray.500")};
  &:hover {
    color: ${(0,h.getTheme)("colors.gray.100")};
  }
`,(0,d.default)(w.default).withConfig({displayName:"styles__StyledBox",componentId:"sc-a8997a5a-1"})`
  margin-left: auto;
  margin-right: auto;

  @media only screen and (max-width: ${D.deviceSize.sm}px) {
    margin-right: unset;
    margin-left: unset;
  }
`,(0,d.default)(w.default).withConfig({displayName:"styles__Wrapper",componentId:"sc-a8997a5a-2"})`
  color: white;
  padding: 40px;
  overflow: hidden;
  border-radius: 8px;
  margin-bottom: 1rem;
  background-color: #0f3460;

  @media only screen and (max-width: 900px) {
    margin-bottom: 3.75rem;
  }
`,a.s([],93961),a.s(["Footer1",()=>C],84894)},20133,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(42343);function e(a){return(0,d.GenIcon)({tag:"svg",attr:{viewBox:"0 0 1024 1024"},child:[{tag:"path",attr:{d:"M946.5 505L560.1 118.8l-25.9-25.9a31.5 31.5 0 0 0-44.4 0L77.5 505a63.9 63.9 0 0 0-18.8 46c.4 35.2 29.7 63.3 64.9 63.3h42.5V940h691.8V614.3h43.4c17.1 0 33.2-6.7 45.3-18.8a63.6 63.6 0 0 0 18.7-45.3c0-17-6.7-33.1-18.8-45.2zM568 868H456V664h112v204zm217.9-325.7V868H632V640c0-22.1-17.9-40-40-40H432c-22.1 0-40 17.9-40 40v228H238.1V542.3h-96l370-369.7 23.1 23.1L882 542.3h-96.1z"},child:[]}]})(a)}var f=a.i(63336),g=a.i(32371),h=a.i(94661),i=a.i(70135),j=a.i(96002),k=a.i(4234),l=a.i(4371);let m=async()=>{try{let a=await fetch("https://admin.unicodeconverter.info/home-menu",{next:{revalidate:3600}});if(!a.ok)return null;return a.json()}catch(a){return console.error("getNavbarServices face error:",a),null}};var n=a.i(45112),o=a.i(75716),p=a.i(71336);let q=o.default.div.withConfig({displayName:"styles__StyledNavbar",componentId:"sc-d1b888b4-0"})`
  position: sticky;
  top: ${p.layoutConstant.headerHeight};
  z-index: 998;
  height: 60px;
  background: ${(0,n.getTheme)("colors.secondary.main")};
  box-shadow: ${(0,n.getTheme)("shadows.regular")};

  .nav-link {
    font-size: 14px;
    cursor: pointer;
    color: white;
    white-space: nowrap;
    transition: all 0.2s ease-in-out;
    &:hover {
      color: ${(0,n.getTheme)("colors.primary.main")};
    }
  }

  /* Specific color for links inside dropdown cards */
  .root-child .nav-link,
  .child .nav-link {
    color: ${(0,n.getTheme)("colors.gray.700")};
    &:hover {
      color: ${(0,n.getTheme)("colors.primary.main")};
    }
  }

  .root-child {
    display: none;
    position: absolute;
    left: 0;
    top: 100%;
    z-index: 99;
    padding-top: 5px; /* Bridge the gap */
  }
  
  .root:hover > .root-child {
    display: block;
  }

  .child {
    display: none;
    position: absolute;
    top: 0;
    left: 100%;
    z-index: 99;
    padding-left: 5px; /* Bridge the gap */
  }
  
  .parent:hover > .child {
    display: block;
  }

  .nav-list-wrapper {
    display: flex;
    /* overflow-x: auto removed as it clips absolute dropdowns */
    scrollbar-width: none;
    -ms-overflow-style: none;
    &::-webkit-scrollbar {
      display: none;
    }
  }

  @media only screen and (max-width: 900px) {
    display: none;
  }
`;function r({navListOpen:a,categories:d}){let[n,o]=(0,c.useState)([{title:"Home",url:"/"}]);(0,c.useEffect)(()=>{let a=a=>{if(!a||!a.menu||!Array.isArray(a.menu))return;let b=a.menu.filter(a=>1===Number(a.checked)).sort((a,b)=>Number(a.menu_order)-Number(b.menu_order)),c={};Array.isArray(a.subCategory)&&a.subCategory.forEach(a=>{a.parent_id&&(c[a.parent_id]||(c[a.parent_id]=[]),c[a.parent_id].push(a))});let d=a=>a?.map(a=>{let b=a.sub_categories||a.category_sub_categories||a.children||c[a.id];return{title:a.cate_name,url:`/category/${a.cate_slug}`,child:d(b)}}),e=b.map(a=>({title:a.category.cate_name,url:`/category/${a.category.cate_slug}`,child:d(a.category.sub_categories||a.category.category_sub_categories||a.category.children||c[a.category.id])}));console.log("Navbar Items:",e),o([{title:"Home",url:"/",isHome:!0},...e])};d&&d.menu?a(d):(async()=>{try{let b=await m();a(b)}catch(a){console.error("Failed to fetch navbar services:",a)}})()},[d]);let p=(a,c=!1)=>a?.map((a,d)=>{let k=`${a.title}-${d}`;return c?a.isHome?(0,b.jsx)(i.default,{className:"nav-link",href:a.url,style:{display:"flex",alignItems:"center"},children:(0,b.jsx)(e,{size:18})},k):a.child&&a.child.length>0?(0,b.jsxs)(h.default,{className:"root",position:"relative",flexDirection:"column",alignItems:"center",children:[(0,b.jsx)(i.default,{href:a.url,children:(0,b.jsxs)(h.default,{alignItems:"center",style:{cursor:"pointer"},children:[(0,b.jsx)(l.Span,{className:"nav-link",children:a.title}),(0,b.jsx)(g.default,{size:"8px",defaultcolor:"currentColor",ml:"5px",children:"chevron-down"})]})}),(0,b.jsx)("div",{className:"root-child",children:(0,b.jsx)(f.default,{borderRadius:8,py:"0.5rem",boxShadow:"large",minWidth:"180px",style:{zIndex:100,overflow:"visible"},children:p(a.child)})})]},k):(0,b.jsx)(i.default,{className:"nav-link",href:a.url,children:(0,b.jsx)(l.Span,{className:"nav-link",children:a.title})},k):a.child&&a.child.length>0?(0,b.jsxs)("div",{className:"parent",style:{position:"relative"},children:[(0,b.jsx)(i.default,{href:a.url,children:(0,b.jsxs)(j.default,{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[(0,b.jsx)(l.Span,{className:"nav-link",children:a.title}),(0,b.jsx)(g.default,{size:"8px",defaultcolor:"currentColor",ml:"5px",children:"chevron-right"})]})}),(0,b.jsx)("div",{className:"child",children:(0,b.jsx)(f.default,{borderRadius:8,py:"0.5rem",boxShadow:"large",minWidth:"230px",style:{zIndex:100,overflow:"visible"},children:p(a.child)})})]},k):(0,b.jsx)(i.default,{href:a.url,children:(0,b.jsx)(j.default,{children:(0,b.jsx)(l.Span,{className:"nav-link",children:a.title})})},k)});return(0,b.jsx)(q,{children:(0,b.jsx)(k.default,{height:"100%",display:"flex",alignItems:"center",children:(0,b.jsx)(h.default,{width:"100%",px:"15px",className:"nav-list-wrapper",justifyContent:"flex-start",style:{gap:20},children:p(n,!0)})})})}a.s(["default",()=>r],20133)}];

//# sourceMappingURL=src_components_11e7f697._.js.map