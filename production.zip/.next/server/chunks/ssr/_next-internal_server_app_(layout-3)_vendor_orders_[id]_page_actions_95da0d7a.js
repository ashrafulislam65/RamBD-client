module.exports=[81977,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28layout-3%29_vendor_orders_%5Bid%5D_page_actions_95da0d7a.js.map