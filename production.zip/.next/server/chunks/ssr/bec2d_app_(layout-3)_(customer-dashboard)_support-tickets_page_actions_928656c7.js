module.exports=[45697,(a,b,c)=>{}];

//# sourceMappingURL=bec2d_app_%28layout-3%29_%28customer-dashboard%29_support-tickets_page_actions_928656c7.js.map