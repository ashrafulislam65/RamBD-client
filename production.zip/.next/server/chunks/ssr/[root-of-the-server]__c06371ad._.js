module.exports=[24361,(a,b,c)=>{b.exports=a.x("util",()=>require("util"))},14747,(a,b,c)=>{b.exports=a.x("path",()=>require("path"))},80719,a=>{"use strict";a.i(64628);var b=a.i(65956),c=a.i(45309),d=a.i(19044),e=a.i(70245),f=a.i(36879),g=a.i(48721),h=a.i(69862),i=a.i(7854),j=a.i(51755),k=a.i(75716),l=a.i(45112);let m=k.default.div.withConfig({shouldForwardProp:a=>(0,l.isValidProp)(a),displayName:"Box",componentId:"sc-9231bc77-0"})(({shadow:a=0,cursor:b="unset",transition:c,theme:d})=>({cursor:b,transition:c,boxShadow:d.shadows[a]}),(0,h.compose)(f.layout,d.space,c.color,b.grid,i.position,g.flexbox,e.border,j.typography));a.s(["default",0,m])},94661,a=>{"use strict";var b=a.i(75716);a.i(64628);var c=a.i(45309),d=a.i(19044),e=a.i(70245),f=a.i(36879),g=a.i(48721),h=a.i(80719),i=a.i(45112);let j=(0,b.default)(h.default).withConfig({shouldForwardProp:a=>(0,i.isValidProp)(a)}).withConfig({displayName:"FlexBox",componentId:"sc-b695c824-0"})`
  display: flex;
  flex-direction: row;
  ${c.color}
  ${d.space}
  ${f.layout}
  ${e.border}
  ${g.flexbox}
`;a.s(["default",0,j])},4371,a=>{"use strict";var b=a.i(87924),c=a.i(64628),d=a.i(19044),e=a.i(45309),f=a.i(70245),g=a.i(36879),h=a.i(25851),i=a.i(51755),j=a.i(75716),k=a.i(45112);let l=j.default.div.withConfig({shouldForwardProp:a=>(0,k.isValidProp)(a)}).withConfig({displayName:"Typography",componentId:"sc-bcc956f9-0"})`
  ${a=>a.ellipsis?`
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  `:""}

  ${c.flex}
  ${d.space}
  ${e.color}
  ${f.border}
  ${g.layout}
  ${h.textStyle}
  ${i.typography}
`;a.s(["H1",0,a=>(0,b.jsx)(l,{as:"h1",mb:"0",mt:"0",fontSize:"30px",...a}),"H2",0,a=>(0,b.jsx)(l,{as:"h2",mb:"0",mt:"0",fontSize:"25px",...a}),"H3",0,a=>(0,b.jsx)(l,{as:"h3",mb:"0",mt:"0",fontSize:"20px",...a}),"H4",0,a=>(0,b.jsx)(l,{as:"h4",mb:"0",mt:"0",fontWeight:"600",fontSize:"17px",...a}),"H5",0,a=>(0,b.jsx)(l,{as:"h5",mb:"0",mt:"0",fontWeight:"600",fontSize:"16px",...a}),"H6",0,a=>(0,b.jsx)(l,{as:"h6",mb:"0",mt:"0",fontWeight:"600",fontSize:"14px",...a}),"Paragraph",0,a=>(0,b.jsx)(l,{as:"p",mb:"0",mt:"0",...a}),"SemiSpan",0,a=>(0,b.jsx)(l,{as:"span",fontSize:"14px",color:"text.muted",...a}),"Small",0,a=>(0,b.jsx)(l,{as:"span",fontSize:"12px",...a}),"Span",0,a=>(0,b.jsx)(l,{as:"span",fontSize:"16px",...a}),"Tiny",0,a=>(0,b.jsx)(l,{as:"span",fontSize:"10px",...a}),"default",0,l])},66500,a=>{"use strict";var b=a.i(75716);a.i(64628);var c=a.i(70245),d=a.i(36879),e=a.i(19044),f=a.i(45112);let g=b.default.img.withConfig({shouldForwardProp:a=>(0,f.isValidProp)(a)}).withConfig({displayName:"Image",componentId:"sc-555dc8bf-0"})`
  ${e.space}
  ${c.border}
  ${d.layout}
`;a.s(["default",0,g])},15799,6167,a=>{"use strict";var b=a.i(28337);let c=async()=>(await b.default.get("/api/users/orders")).data,d=async()=>(await b.default.get("/api/users/order-ids")).data,e=async a=>{try{return(await b.default.get("/api/users/order",{params:{id:a}})).data}catch(a){return console.error("Failed to fetch order:",a),null}};a.s(["default",0,{getOrders:c,getOrder:e,getIds:d}],15799);var f=a.i(87924),g=a.i(75716),h=a.i(56711),i=a.i(80719),j=a.i(66500),k=a.i(94661),l=a.i(4371);let m=(0,g.default)(i.default).withConfig({displayName:"Invoice__StyledInvoice",componentId:"sc-e082b416-0"})`
  background: #fff;
  padding: 15px 25px;
  max-width: 900px;
  margin: auto;
  font-family: 'Inter', sans-serif;
  color: #333;
  line-height: 1.1;

  @media print {
    padding: 0 !important;
    margin: 0 !important;
    max-width: 100% !important;
    box-shadow: none !important;
    
    .hide-from-print {
      display: none !important;
    }

    @page {
      margin: 8mm !important;
      size: A4;
    }
    
    body {
      -webkit-print-color-adjust: exact;
    }
  }

  .header {
    border-bottom: 2px solid #F2F4F8;
    padding-bottom: 8px;
    margin-bottom: 8px;
    break-inside: avoid;
  }

  .company-info {
    text-align: left;
  }

  .invoice-title {
    color: #1c4b78;
    margin-bottom: 1px;
    font-size: 20px;
    font-weight: 700;
  }

  .meta-section {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;
    font-size: 10px;
    break-inside: avoid;
  }

  .meta-column {
    flex: 1;
    line-height: 1.2;
  }

  .invoice-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 8px;
    break-inside: auto;
  }

  .invoice-table thead {
    display: table-header-group;
  }

  .invoice-table tr {
    break-inside: avoid;
    break-after: auto;
  }

  .invoice-table th,
  .invoice-table td {
    border: 1px solid #ddd;
    padding: 3px 5px;
    text-align: left;
    font-size: 9px;
  }

  .invoice-table th {
    background-color: #f8f9fa;
    font-weight: 600;
    color: #444;
  }

  .product-name {
    color: #1c4b78;
    font-weight: 700;
    font-size: 9.5px;
  }

  .product-sn {
    color: #1c4b78;
    font-weight: 700;
    display: block;
    margin-top: 0px;
    font-size: 8.5px;
  }

  .blue-val {
    color: #1c4b78;
    font-weight: 700;
  }

  .total-val {
    color: #27ae60;
    font-weight: 700;
  }

  .summary-section {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 10px;
    break-inside: avoid;
  }

  .summary-table {
    width: 230px;
  }

  .summary-row {
    display: flex;
    justify-content: space-between;
    padding: 1px 0;
    font-size: 10px;
  }

  .summary-row.total {
    border-top: 1px solid #ccc;
    padding-top: 3px;
    margin-top: 3px;
    font-weight: 700;
    font-size: 11px;
  }

  .signature-section {
    display: flex;
    justify-content: space-around;
    margin-top: 30px;
    margin-bottom: 15px;
    break-inside: avoid;
  }

  .signature-line {
    width: 180px;
    border-top: 1.5px solid #333;
    text-align: center;
    padding-top: 4px;
    font-size: 9px;
    color: #333;
    font-weight: 500;
  }

  .terms-section {
    margin-top: 8px;
    font-size: 8.5px;
    color: #444;
    line-height: 1.3;
    break-inside: avoid;
  }

  .terms-title {
    font-weight: 700;
    text-decoration: underline;
    margin-bottom: 2px;
    color: #333;
    font-size: 9px;
  }

  .logo-img {
    width: 45px;
    height: 45px;
    object-fit: contain;
    margin-right: 15px;
  }
`;a.s(["default",0,({order:a})=>a?(0,f.jsxs)(m,{id:"printable-invoice",children:[(0,f.jsx)(i.default,{className:"header",children:(0,f.jsxs)(k.default,{justifyContent:"space-between",alignItems:"flex-start",children:[(0,f.jsxs)(k.default,{alignItems:"center",children:[(0,f.jsx)(j.default,{src:"/assets/images/rambd_logo.webp",className:"logo-img",alt:"Logo"}),(0,f.jsxs)(i.default,{className:"company-info",children:[(0,f.jsx)(l.H3,{className:"invoice-title",color:"inherit",children:"RamBD"}),(0,f.jsx)(l.default,{fontSize:"10px",display:"block",color:"#666",children:"Address: House 33, Road 04, Dhanmondi, Dhaka-1205"}),(0,f.jsx)(l.default,{fontSize:"10px",display:"block",color:"#666",children:"Contact: +880-1650-666999"}),(0,f.jsx)(l.default,{fontSize:"10px",display:"block",color:"#666",children:"Email: info@rambd.com           Website: https://rambd.com"})]})]}),(0,f.jsx)(i.default,{textAlign:"right",children:(0,f.jsxs)(l.default,{fontSize:"11px",fontWeight:"600",color:"#333",children:["RB",(0,h.format)(new Date,"yyyyMMdd")]})})]})}),(0,f.jsxs)(i.default,{className:"meta-section",children:[(0,f.jsxs)(i.default,{className:"meta-column",children:[(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Order ID:"})," RB",a.id.substring(0,10).toUpperCase()]}),(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Customer:"})," ",a.user?.name?.firstName||"Customer"]}),(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Contact:"})," ",a.user?.phone||"N/A"]}),(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Address:"})," ",a.shippingAddress||"N/A"]}),(a.district||a.thana)&&(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"District/Thana:"})," ",[a.district,a.thana].filter(Boolean).join(", ")]})]}),(0,f.jsxs)(i.default,{className:"meta-column",textAlign:"right",children:[(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Invoice No::"})," RB",a.id.substring(0,10).toUpperCase()]}),(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Order Date:"})," ",(0,h.format)(new Date(a.createdAt),"yyyy-MM-dd HH:mm:ss")]}),(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Delivery Date:"})," N/A"]}),(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Sales Person:"})," RamBD"]}),(0,f.jsxs)(l.Paragraph,{mb:"2px",children:[(0,f.jsx)("strong",{children:"Payment Method:"})," Cash On Delivery"]})]})]}),(0,f.jsxs)("table",{className:"invoice-table",children:[(0,f.jsx)("thead",{children:(0,f.jsxs)("tr",{children:[(0,f.jsx)("th",{style:{width:"50px"},children:"#SL"}),(0,f.jsx)("th",{children:"Product Details"}),(0,f.jsx)("th",{style:{width:"80px"},children:"Warranty"}),(0,f.jsx)("th",{style:{width:"80px"},children:"Quantity"}),(0,f.jsx)("th",{style:{width:"100px"},children:"Unit Price"}),(0,f.jsx)("th",{style:{width:"100px"},children:"Total"})]})}),(0,f.jsx)("tbody",{children:a.items.map((a,b)=>(0,f.jsxs)("tr",{children:[(0,f.jsx)("td",{children:b+1}),(0,f.jsxs)("td",{children:[(0,f.jsx)("span",{className:"product-name",children:a.product_name}),(0,f.jsx)("span",{className:"product-sn",children:"S/N: 185742510"})]}),(0,f.jsx)("td",{className:"blue-val",children:"0"}),(0,f.jsx)("td",{className:"blue-val",children:a.product_quantity}),(0,f.jsx)("td",{className:"blue-val",children:a.product_price.toLocaleString(void 0,{minimumFractionDigits:2})}),(0,f.jsxs)("td",{className:"total-val",children:["৳",a.product_price.toLocaleString(void 0,{minimumFractionDigits:2})]})]},b))})]}),(0,f.jsx)(i.default,{className:"summary-section",children:(0,f.jsxs)(i.default,{className:"summary-table",children:[(0,f.jsxs)(i.default,{className:"summary-row",children:[(0,f.jsx)(l.default,{children:"Total Amount : "}),(0,f.jsxs)(l.default,{fontWeight:"700",color:"#e74c3c",children:["৳",a.totalPrice.toLocaleString(void 0,{minimumFractionDigits:2})]})]}),(0,f.jsxs)(i.default,{className:"summary-row",children:[(0,f.jsx)(l.default,{children:"Promotion discount : "}),(0,f.jsxs)(l.default,{children:["৳",a.discount?.toLocaleString(void 0,{minimumFractionDigits:2})||"0.00"]})]}),(0,f.jsxs)(i.default,{className:"summary-row",children:[(0,f.jsx)(l.default,{children:"VAT : "}),(0,f.jsx)(l.default,{children:"N/A"})]}),(0,f.jsxs)(i.default,{className:"summary-row",children:[(0,f.jsx)(l.default,{children:"Shipping Cost : "}),(0,f.jsx)(l.default,{color:"#e74c3c",children:"৳150.00"})]}),(0,f.jsxs)(i.default,{className:"summary-row total",children:[(0,f.jsx)(l.default,{children:"Total Payable Amount:"}),(0,f.jsxs)(l.default,{children:["৳",(a.totalPrice+150-(a.discount||0)).toLocaleString(void 0,{minimumFractionDigits:2})]})]})]})}),(0,f.jsxs)(i.default,{className:"signature-section",children:[(0,f.jsx)(i.default,{className:"signature-line",children:"Customer Signature"}),(0,f.jsx)(i.default,{className:"signature-line",children:"Admin Signature"})]}),(0,f.jsxs)(i.default,{className:"terms-section",children:[(0,f.jsx)(l.default,{className:"terms-title",children:"Terms & Condition"}),(0,f.jsxs)(l.default,{mb:"4px",children:["In case of product mismatch, damage, expiry, or billing errors, the customer must immediately return the product to the Delivery Manager or inform us by calling ",(0,f.jsx)("strong",{children:"01958 666 999"})," between ",(0,f.jsx)("strong",{children:"9:00 AM and 6:00 PM"}),"."]}),(0,f.jsxs)(l.default,{mb:"4px",children:["For eligible cases, refunds or returns will be processed within ",(0,f.jsx)("strong",{children:"7-10 business working days"})," from the date of claim submission."]}),(0,f.jsx)(l.default,{mb:"4px",children:"If no refund or cancellation policy is applicable to a specific product, that will be clearly stated on the product page or in our policies."}),(0,f.jsxs)(l.default,{children:["For any queries, complaints, or feedback, please contact us at ",(0,f.jsx)("strong",{children:"+880-1958-666999"})," between ",(0,f.jsx)("strong",{children:"9:00 AM and 6:00 PM"}),"."]})]})]}):null],6167)},55361,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(50944),e=a.i(80719),f=a.i(15799),g=a.i(6167);function h(){let a=(0,d.useSearchParams)().get("id")||"latest",[h,i]=(0,c.useState)(null),[j,k]=(0,c.useState)(!0);return((0,c.useEffect)(()=>{(async()=>{try{let b=await f.default.getOrders(),c=b.find(b=>b.id.includes(a)||"latest"===a);c?i(c):b.length>0&&i(b[0])}catch(a){console.error("Error fetching order:",a)}finally{k(!1)}})()},[a]),j)?(0,b.jsx)(e.default,{textAlign:"center",p:"40px",children:"Loading Invoice..."}):h?(0,b.jsx)(e.default,{py:"20px",children:(0,b.jsx)(g.default,{order:h})}):(0,b.jsx)(e.default,{textAlign:"center",p:"40px",children:"Invoice not found."})}function i(){return(0,b.jsx)(c.Suspense,{fallback:(0,b.jsx)(e.default,{textAlign:"center",p:"40px",children:"Loading..."}),children:(0,b.jsx)(h,{})})}a.s(["default",()=>i])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__c06371ad._.js.map