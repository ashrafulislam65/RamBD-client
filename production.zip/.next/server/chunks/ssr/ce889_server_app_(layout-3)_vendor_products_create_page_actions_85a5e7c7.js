module.exports=[89492,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28layout-3%29_vendor_products_create_page_actions_85a5e7c7.js.map