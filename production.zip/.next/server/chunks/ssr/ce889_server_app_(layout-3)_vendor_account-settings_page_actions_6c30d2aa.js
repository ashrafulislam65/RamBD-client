module.exports=[17943,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28layout-3%29_vendor_account-settings_page_actions_6c30d2aa.js.map