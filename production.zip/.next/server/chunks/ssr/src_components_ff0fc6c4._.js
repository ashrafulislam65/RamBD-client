module.exports=[80719,a=>{"use strict";a.i(64628);var b=a.i(65956),c=a.i(45309),d=a.i(19044),e=a.i(70245),f=a.i(36879),g=a.i(48721),h=a.i(69862),i=a.i(7854),j=a.i(51755),k=a.i(75716),l=a.i(45112);let m=k.default.div.withConfig({shouldForwardProp:a=>(0,l.isValidProp)(a),displayName:"Box",componentId:"sc-9231bc77-0"})(({shadow:a=0,cursor:b="unset",transition:c,theme:d})=>({cursor:b,transition:c,boxShadow:d.shadows[a]}),(0,h.compose)(f.layout,d.space,c.color,b.grid,i.position,g.flexbox,e.border,j.typography));a.s(["default",0,m])},94661,a=>{"use strict";var b=a.i(75716);a.i(64628);var c=a.i(45309),d=a.i(19044),e=a.i(70245),f=a.i(36879),g=a.i(48721),h=a.i(80719),i=a.i(45112);let j=(0,b.default)(h.default).withConfig({shouldForwardProp:a=>(0,i.isValidProp)(a)}).withConfig({displayName:"FlexBox",componentId:"sc-b695c824-0"})`
  display: flex;
  flex-direction: row;
  ${c.color}
  ${d.space}
  ${f.layout}
  ${e.border}
  ${g.flexbox}
`;a.s(["default",0,j])}];

//# sourceMappingURL=src_components_ff0fc6c4._.js.map