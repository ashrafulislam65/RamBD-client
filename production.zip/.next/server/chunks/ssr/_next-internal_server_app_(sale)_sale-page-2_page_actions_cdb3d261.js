module.exports=[16271,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28sale%29_sale-page-2_page_actions_cdb3d261.js.map