module.exports=[52773,a=>{"use strict";var b=a.i(7997),c=a.i(717);function d({children:a}){return(0,b.jsx)(c.Fragment,{children:a})}a.s(["default",()=>d])}];

//# sourceMappingURL=src_app_%28layout-3%29_%28checkout%29_layout_tsx_36d8d0ba._.js.map