module.exports=[98892,a=>{"use strict";var b=a.i(7997);function c(){return(0,b.jsx)("h1",{children:"Loading..."})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_%28layout-3%29_shops_%5Bslug%5D_loading_tsx_0e5cf237._.js.map