module.exports=[90868,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28layout-3%29_product_%5Bslug%5D_page_actions_0652df3b.js.map