module.exports=[72640,a=>{"use strict";var b=a.i(7997);function c(){return(0,b.jsx)("h1",{children:"Loading..."})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_%28layout-3%29_product_%5Bslug%5D_loading_tsx_dfc75768._.js.map