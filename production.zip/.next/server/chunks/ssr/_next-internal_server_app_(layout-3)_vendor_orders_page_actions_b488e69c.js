module.exports=[89213,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28layout-3%29_vendor_orders_page_actions_b488e69c.js.map