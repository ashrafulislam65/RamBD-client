module.exports=[86667,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invoice_page_actions_0aea5fa3.js.map