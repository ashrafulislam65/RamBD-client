module.exports=[71123,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28sale%29_sale-page-1_page_actions_464c5dbd.js.map