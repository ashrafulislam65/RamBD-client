module.exports=[4316,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28layout-3%29_vendor_products_%5Bslug%5D_page_actions_bd4eaca6.js.map