module.exports=[41108,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28layout-3%29_vendor_products_page_actions_dc2424e6.js.map