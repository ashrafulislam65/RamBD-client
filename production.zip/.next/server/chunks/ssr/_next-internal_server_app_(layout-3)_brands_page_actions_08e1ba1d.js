module.exports=[41968,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28layout-3%29_brands_page_actions_08e1ba1d.js.map